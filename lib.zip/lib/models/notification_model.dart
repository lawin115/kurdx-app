// lib/models/notification_model.dart

class NotificationModel {
  final String id;
  final String message;
  final int? auctionId;
  final DateTime createdAt;
  final DateTime? readAt;

  NotificationModel({
    required this.id,
    required this.message,
    this.auctionId,
    required this.createdAt,
    this.readAt,
  });

  bool get isRead => readAt != null;

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'],
      message: json['data']['message'] ?? 'No message content',
      auctionId: json['data']['auction_id'],
      createdAt: DateTime.parse(json['created_at']),
      readAt: json['read_at'] == null ? null : DateTime.parse(json['read_at']),
    );
  }
}