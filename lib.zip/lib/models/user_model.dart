class User {
  final int id;
  final String name;
  final String email;
  final String role; // <-- ئەمە زیاد بکە
  final String? profilePhotoUrl; // <-- ئەمە زیاد بکە
 User({required this.id, required this.name, required this.email, required this.role, this.profilePhotoUrl});

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json['id'],
        name: json['name'],
        email: json['email'],
        role: json['role'] ?? 'user', // نرخی بنەڕەتی 'user'ـە
         profilePhotoUrl: json['profile_photo_url'], 
      );

        Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'role': role,
      'profile_photo_url': profilePhotoUrl,
    };
  }
}