class AuctionImage {
  final int id;
  final String url;

  AuctionImage({required this.id, required this.url});

factory AuctionImage.fromJson(Map<String, dynamic> json) {
  const String baseUrl = "http://192.168.1.25:8000"; // Your Laravel server base URL
  String imageUrl = json['path'].startsWith('http') 
      ? json['path'] 
      : '$baseUrl/storage/${json['path']}';

  // Log the image URL to verify it's correct
  print("Generated Image URL: $imageUrl");

  return AuctionImage(
    id: json['id'],
    url: imageUrl,
  );
}


}
