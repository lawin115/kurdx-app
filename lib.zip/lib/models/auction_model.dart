// lib/models/auction_model.dart

import 'dart:convert';
import './user_model.dart';
import './bid_model.dart';
import './comment_model.dart';
import './auction_image_model.dart';

List<Auction> auctionFromJson(String str) => List<Auction>.from(json.decode(str).map((x) => Auction.fromJson(x)));

class Auction {
  final int id;
  final String title;
  final String description;
  final double startingPrice;
  final double currentPrice;
  final DateTime endTime;
  final int userId;
  final User? user;
  final List<AuctionImage> images;
  final List<Bid> bids;
  final List<Comment> comments;
  
  final String? imageUrl; // It should be a String, not List

  Auction({
    required this.id,
    required this.title,
    required this.description,
    required this.startingPrice,
    required this.currentPrice,
    required this.endTime,
    required this.userId,
    this.user,
    required this.images,
    required this.bids,
    required this.comments,
    this.imageUrl, // Image URL as String
  });

  factory Auction.fromJson(Map<String, dynamic> json) {
    // Safely assign imageUrl from the first image in the images list
    String? imageUrl;
    if (json["images"] != null && json["images"].isNotEmpty) {
      imageUrl = json["images"][0]["url"]; // Get the first image URL
    }

    return Auction(
      id: json["id"],
      title: json["title"] ?? 'No Title',
      description: json["description"] ?? '',
      startingPrice: double.parse(json["starting_price"]?.toString() ?? '0.0'),
      currentPrice: double.parse(json["current_price"]?.toString() ?? '0.0'),
      endTime: DateTime.parse(json["end_time"]),
      userId: json["user_id"],
      user: json["user"] == null ? null : User.fromJson(json["user"]),
      images: json["images"] == null
          ? []
          : List<AuctionImage>.from(json["images"].map((x) => AuctionImage.fromJson(x))),
      bids: json["bids"] == null
          ? []
          : List<Bid>.from(json["bids"].map((x) => Bid.fromJson(x))),
      comments: json["comments"] == null
          ? []
          : List<Comment>.from(json["comments"].map((x) => Comment.fromJson(x))),
      imageUrl: imageUrl, // Correctly assign imageUrl
    );
  }

  get category => null;

  
  bool get isEnded => DateTime.now().isAfter(endTime);

  // ===== Copy with method =====
  Auction copyWith({
    int? id,
    String? title,
    String? description,
    double? startingPrice,
    double? currentPrice,
    DateTime? endTime,
    int? userId,
    User? user,
    List<AuctionImage>? images,
    List<Bid>? bids,
    List<Comment>? comments,
    String? imageUrl,
  }) {
    return Auction(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      startingPrice: startingPrice ?? this.startingPrice,
      currentPrice: currentPrice ?? this.currentPrice,
      endTime: endTime ?? this.endTime,
      userId: userId ?? this.userId,
      user: user ?? this.user,
      images: images ?? this.images,
      bids: bids ?? this.bids,
      comments: comments ?? this.comments,
      imageUrl: imageUrl ?? this.imageUrl,
    );
  }

  isLive() {}
}
