// lib/screens/edit_profile_screen.dart

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kurdpoint/screens/login_screen.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _apiService = ApiService();
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  File? _imageFile;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    // پڕکردنەوەی فۆڕمەکە بە زانیارییەکانی ئێستای بەکارهێنەر
    final user = Provider.of<AuthProvider>(context, listen: false).user;
    _nameController = TextEditingController(text: user?.name ?? '');
    _emailController = TextEditingController(text: user?.email ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 50);
    if (pickedFile != null) {
      setState(() => _imageFile = File(pickedFile.path));
    }
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    final auth = Provider.of<AuthProvider>(context, listen: false);
    
    final updatedUser = await _apiService.updateUserProfile(
      token: auth.token!,
      name: _nameController.text,
      email: _emailController.text,
      photoFile: _imageFile,
    );
    
    if (mounted) {
      setState(() => _isLoading = false);
      if (updatedUser != null) {
        auth.updateUser(updatedUser);
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پرۆفایل بە سەرکەوتوویی نوێکرایەوە'), backgroundColor: Colors.green));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هەڵەیەک لە نوێکردنەوەدا ڕوویدا'), backgroundColor: Colors.red));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // وەرگرتنی وێنەی پرۆفایلی ئێستا بۆ پیشاندان
    final currentUserImageUrl = Provider.of<AuthProvider>(context).user?.profilePhotoUrl;

    return Scaffold(
      appBar: AppBar(
        title: const Text('گۆڕینی پرۆفایل'),
        actions: [
          // دوگمەی پاشەکەوتکردن لە AppBar
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _isLoading ? null : _submitForm,
          )
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // ===== بەشی وێنەی پرۆفایل =====
                    Center(
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: 70,
                            backgroundColor: Colors.grey[200],
                            // ئەگەر وێنەیەکی نوێ هەڵبژێردرابوو، ئەوە پیشان بدە
                            // ئەگەرنا، وێنەی ئێستا پیشان بدە (ئەگەر هەبوو)
                            // ئەگەر هیچ کام نەبوو، ئایکۆن پیشان بدە
                            backgroundImage: _imageFile != null
                                ? FileImage(_imageFile!)
                                : (currentUserImageUrl != null
                                    ? NetworkImage(currentUserImageUrl)
                                    : null) as ImageProvider?,
                            child: _imageFile == null && currentUserImageUrl == null
                                ? const Icon(Icons.person, size: 80, color: Colors.grey)
                                : null,
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Material(
                              color: Theme.of(context).primaryColor,
                              shape: const CircleBorder(),
                              clipBehavior: Clip.antiAlias,
                              child: IconButton(
                                icon: const Icon(Icons.camera_alt, color: Colors.white),
                                onPressed: _pickImage,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),

                    // ===== خانەی ناو =====
                    TextFormField(
                      controller: _nameController,
                      decoration: const InputDecoration(labelText: 'ناو'),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'تکایە ناوەکەت بنووسە.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // ===== خانەی ئیمەیڵ =====
                    TextFormField(
                      controller: _emailController,
                      decoration: const InputDecoration(labelText: 'ئیمەیڵ'),
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null || !value.contains('@')) {
                          return 'تکایە ئیمەیڵێکی دروست بنووسە.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 32),

                    // ===== دوگمەی پاشەکەوتکردن (جێگرەوە) =====
                    ElevatedButton(
                      onPressed: _isLoading ? null : _submitForm,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: const Text('پاشەکەوتکردنی گۆڕانکارییەکان'),
                    ),
                    const SizedBox(height: 16), // بۆشاییەک لە نێوان دوگمەکان

OutlinedButton.icon(
  icon: const Icon(Icons.logout),
  label: const Text('دەرچوون'),
  onPressed: () {
    // 1. بانگکردنی функцIAی logout لە AuthProvider
    Provider.of<AuthProvider>(context, listen: false).logout();

    // 2. گەڕاندنەوەی بەکارهێنەر بۆ لاپەڕەی لۆگین
    // بەکارهێنانی pushAndRemoveUntil بۆ سڕینەوەی هەموو لاپەڕەکانی پێشوو
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (Route<dynamic> route) => false, // ئەمە وا دەکات هەموو routeـەکانی پێشوو بسڕدرێنەوە
    );
  },
  style: OutlinedButton.styleFrom(
    foregroundColor: Colors.red, // ڕەنگی نووسین و ئایکۆن
    side: const BorderSide(color: Colors.red), // ڕەنگی چوارچێوەکە
    padding: const EdgeInsets.symmetric(vertical: 16),
  ),
)
                  ],
                ),
              ),
            ),
    );
  }
}