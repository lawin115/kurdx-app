import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import '../models/auction_model.dart';
import '../models/order_model.dart';
import '../models/user_model.dart';
import '../providers/auth_provider.dart';
import '../providers/theme_provider.dart';
import '../services/api_service.dart';
import '../auction_detail_screen.dart';
import './edit_profile_screen.dart';
import './login_screen.dart';
import '../widgets/auction_list_card.dart';

// Helper function to create the Instagram-style gradient
LinearGradient _instagramGradient() {
  
  return const LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF833AB4), // Purple
      Color.fromARGB(255, 48, 41, 43), // Red
      Color.fromARGB(255, 29, 26, 26), // Pink
      Color.fromARGB(255, 26, 11, 8), // Orange
      Color.fromARGB(255, 51, 30, 19), // Yellow
    ],
  );
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with TickerProviderStateMixin {
  final ApiService _apiService = ApiService();
  Map<String, dynamic>? _stats;
  List<Auction> _activeAuctions = [];
  List<Order> _soldOrders = [];
  List<Auction> _participatedAuctions = [];
  List<Auction>? _watchedAuctions;
  bool _isLoading = true;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _fetchData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _fetchData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final token = authProvider.token;
    if (token == null) {
      if (mounted) {
        setState(() => _isLoading = false);
      }
      return;
    }

    final isVendor = authProvider.user?.role == 'vendor';
    final futures = [
      _apiService.getMyActivity(token),
      _apiService.getWatchlist(token),
    ];
    if (isVendor) {
      futures.add(_apiService.getSoldAuctions(token));
    }

    try {
      final results = await Future.wait(futures);
      if (mounted) {
        setState(() {
          final activityData = results[0] as Map<String, dynamic>?;
          _watchedAuctions = results[1] as List<Auction>?;

          if (activityData != null) {
            _stats = activityData['stats'];
            final allMyAuctions = (activityData['my_auctions'] as List? ?? []).map((d) => Auction.fromJson(d)).toList();
            _activeAuctions = allMyAuctions.where((a) => !a.isEnded).toList();
            _participatedAuctions = (activityData['participated_auctions'] as List? ?? []).map((d) => Auction.fromJson(d)).toList();
          }

          if (isVendor && results.length > 2) {
            _soldOrders = results[2] as List<Order>? ?? [];
          }

          _tabController = TabController(length: isVendor ? 4 : 2, vsync: this);
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load data: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _onEditProfile() {
    Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => const EditProfileScreen()));
  }

  void _onLogout() {
    Provider.of<AuthProvider>(context, listen: false).logout();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (c) => const LoginScreen()),
      (route) => false,
    );
  }

Widget _buildAuctionList(List<Auction> auctions, String emptyMessage) {
  if (auctions.isEmpty) {
    return Center(
      child: Text(
        emptyMessage,
        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Theme.of(context).disabledColor,
            ),
      ),
    );
  }

  return MasonryGridView.count(
    padding: const EdgeInsets.all(8),
    crossAxisCount: 3,
    mainAxisSpacing: 10,
    crossAxisSpacing: 0,
    itemCount: auctions.length,
    itemBuilder: (context, index) {
      final auction = auctions[index];
      return AuctionGridCard(
        auction: auction,
        isLarge: index % 5 == 0, // Make every 5th item larger
      );
    },
  );
}
  Widget _buildSoldOrdersList(List<Order> orders, String emptyMessage) {
    final theme = Theme.of(context);
    if (orders.isEmpty) {
      return Center(
        child: Text(
          emptyMessage,
          style: theme.textTheme.bodyLarge?.copyWith(color: theme.disabledColor),
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: orders.length,
      itemBuilder: (ctx, index) {
        final order = orders[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Stack(
            children: [
              AuctionGridCard(auction: order.auction),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle_outline, color: theme.colorScheme.primary, size: 40),
                        const SizedBox(height: 8),
                        Text(
                          'Sold to ${order.user?.name ?? "Unknown"}',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Final price: \$${order.finalPrice}',
                          style: theme.textTheme.bodyLarge,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildProfileHeader(User? user) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    return Container(
      decoration: BoxDecoration(gradient: _instagramGradient()),
      padding: const EdgeInsets.fromLTRB(8, 20, 8, 70),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: CircleAvatar(
                  radius: 40,
                  backgroundColor: Colors.white,
                  backgroundImage: user?.profilePhotoUrl != null
                      ? NetworkImage(user!.profilePhotoUrl!)
                      : null,
                  child: user?.profilePhotoUrl == null
                      ? Icon(Icons.person_outline, size: 40, color: theme.colorScheme.primary)
                      : null,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      user?.name ?? 'User',
                      style: textTheme.headlineSmall?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      user?.email ?? '',
                      style: textTheme.bodyLarge?.copyWith(
                        color: Colors.white.withOpacity(0.8),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (_stats != null) _buildStatsRow(),
          const SizedBox(height: 8),
          _buildThemeSwitcher(),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildStatItem('Auctions', _stats?['auctions_count'] ?? 0),
        _buildStatItem('Bids', _stats?['bids_count'] ?? 0),
        _buildStatItem('Won', _stats?['won_count'] ?? 0),
      ],
    );
  }

  Widget _buildStatItem(String label, dynamic value) {
    final textTheme = Theme.of(context).textTheme;
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              value.toString(),
              style: textTheme.titleMedium?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: textTheme.bodySmall?.copyWith(
                color: Colors.white.withOpacity(0.8),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThemeSwitcher() {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textTheme = theme.textTheme;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(
            themeProvider.themeMode == ThemeMode.dark
                ? Icons.dark_mode_outlined
                : Icons.light_mode_outlined,
            color: Colors.white,
          ),
          const SizedBox(width: 4),
          Text(
            'Theme',
            style: textTheme.bodyMedium?.copyWith(color: Colors.white),
          ),
          const Spacer(),
          DropdownButton<ThemeMode>(
            value: themeProvider.themeMode,
            underline: const SizedBox(),
            dropdownColor: colorScheme.surface,
            icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
            items: [
              DropdownMenuItem(
                value: ThemeMode.system,
                child: Text('System', style: textTheme.bodyMedium?.copyWith(color: colorScheme.onSurface)),
                 ),
              DropdownMenuItem(
                value: ThemeMode.light,
                child: Text('Light', style: textTheme.bodyMedium?.copyWith(color: colorScheme.onSurface)),
              ),
              
                       
              DropdownMenuItem(
                value: ThemeMode.dark,
                child: Text('Dark', style: textTheme.bodyMedium?.copyWith(color: colorScheme.onSurface)),
              ),
            ],
            onChanged: (value) {
              if (value != null) themeProvider.setThemeMode(value);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final user = authProvider.user;
    final isVendor = user?.role == 'vendor';
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textTheme = theme.textTheme;

    // Define tabs dynamically based on vendor role
    final tabs = <Tab>[];
    if (isVendor) {
      tabs.add(const Tab(text: 'Active'));
      tabs.add(const Tab(text: 'Sold'));
    }
    tabs.add(const Tab(text: 'Participated'));
    tabs.add(const Tab(text: 'Watched'));

    // Define tab views dynamically based on vendor role
    final tabViews = <Widget>[];
    if (isVendor) {
      tabViews.add(_buildAuctionList(_activeAuctions, "No active auctions"));
      tabViews.add(_buildSoldOrdersList(_soldOrders, "No sold items yet"));
    }
    tabViews.add(_buildAuctionList(_participatedAuctions, "No participated auctions"));
    tabViews.add(
      _watchedAuctions == null
          ? const Center(child: Text('Error loading data'))
          : _buildAuctionList(_watchedAuctions!, "Watchlist is empty"),
    );

    return Scaffold(
      backgroundColor: colorScheme.background,
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: colorScheme.primary))
          : NestedScrollView(
              headerSliverBuilder: (context, innerBoxIsScrolled) {
                return [
                  SliverAppBar(
                    expandedHeight: 280,
                    pinned: true,
                    floating: false,
                    backgroundColor: colorScheme.surface,
                    elevation: 0,
                    leading: null,
                    automaticallyImplyLeading: false,
                    flexibleSpace: FlexibleSpaceBar(
                      background: _buildProfileHeader(user),
                      centerTitle: false,
                      titlePadding: const EdgeInsetsDirectional.only(start: 16, bottom: 16),
                      title: AnimatedOpacity(
                        duration: const Duration(milliseconds: 200),
                        opacity: innerBoxIsScrolled ? 1.0 : 0.0,
                        child: Text(
                          user?.name ?? 'User',
                          style: textTheme.titleLarge?.copyWith(
                            color: colorScheme.onSurface,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    actions: [
                      IconButton(
                        icon: Icon(Icons.edit_outlined, color: colorScheme.onSurface),
                        onPressed: _onEditProfile,
                      ),
                      IconButton(
                        icon: Icon(Icons.logout_outlined, color: colorScheme.onSurface),
                        onPressed: _onLogout,
                      ),
                    ],
                    bottom: PreferredSize(
                      preferredSize: const Size.fromHeight(48),
                      child: Container(
                        color: colorScheme.surface,
                        child: TabBar(
                          controller: _tabController,
                          isScrollable: false,
                          indicatorSize: TabBarIndicatorSize.tab,
                          indicator: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(
                                color: colorScheme.primary,
                                width: 2.0,
                              ),
                            ),
                          ),
                          labelColor: colorScheme.onSurface,
                          unselectedLabelColor: colorScheme.onSurfaceVariant.withOpacity(0.6),
                          labelStyle: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
                          unselectedLabelStyle: textTheme.titleSmall,
                          tabs: tabs,
                        ),
                      ),
                    ),
                  ),
                ];
              },
              body: TabBarView(
                controller: _tabController,
                children: tabViews,
              ),
            ),
    );
  }
}