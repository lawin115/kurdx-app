// lib/screens/onboarding_screen.dart

import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import './main_screen.dart'; // یان LoginScreen

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  void _onIntroEnd(context) {
    // دوای تەواوبوونی شاشەکان، بەکارهێنەر بنێرە بۆ لاپەڕەی سەرەکی
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return IntroductionScreen(
      pages: [
        PageViewModel(
          title: "بەخێربێیت بۆ Kurd Bids",
          body: "باشترین شوێن بۆ دۆزینەوەی مەزادی نایاب و بەشداریکردن تێیدا.",
          image: const Center(child: Icon(Icons.gavel, size: 100)),
        ),
        PageViewModel(
          title: "نرخ زیاد بکە و ببە براوە",
          body: "بە ئاسانی چاودێری مەزادەکان بکە و نرخەکانت زیاد بکە بۆ بردنەوە.",
          image: const Center(child: Icon(Icons.trending_up, size: 100)),
        ),
        PageViewModel(
          title: "ئاسان و سەلامەت",
          body: "ئێمە ئەزموونێکی سەلامەت و ئاسانت بۆ دابین دەکەین.",
          image: const Center(child: Icon(Icons.security, size: 100)),
        ),
      ],
      onDone: () => _onIntroEnd(context),
      showSkipButton: true,
      skip: const Text("پەڕین"),
      next: const Icon(Icons.arrow_forward),
      done: const Text("دەستپێبکە", style: TextStyle(fontWeight: FontWeight.w600)),
    );
  }
}