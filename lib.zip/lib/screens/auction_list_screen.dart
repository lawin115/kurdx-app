import 'dart:async';
import 'package:flutter/material.dart';
import 'package:kurdpoint/providers/notification_provider.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:intl/intl.dart';
import 'package:timer_builder/timer_builder.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

import '../models/auction_model.dart';
import '../models/category_model.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../auction_detail_screen.dart';

class AuctionListScreen extends StatefulWidget {
  const AuctionListScreen({super.key});
  @override
  State<AuctionListScreen> createState() => _AuctionListScreenState();
}

class _AuctionListScreenState extends State<AuctionListScreen> {
  final TextEditingController _searchController = TextEditingController();
  final ApiService _apiService = ApiService();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _searchFocusNode = FocusNode();
  Timer? _debounce;

  List<Auction> _auctions = [];

  int _currentPage = 1;
  bool _isLoading = false;
  bool _isFirstLoad = true;
  bool _hasMore = true;
  int? _selectedCategoryId;
  bool _isGridView = true;
  bool _isSearching = false;
  bool _showLiveOnly = false;

  @override
  void initState() {
    super.initState();
    // **باشترکردنی ١: دەستپێکردنی بارکردنی داتا ڕاستەوخۆ**
    // ئەمە وا دەکات لەگەڵ کردنەوەی شاشەکە، داتاکان دەستبەجێ باربکرێن.
    _fetchAuctions();
 
    _scrollController.addListener(_scrollListener);
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_scrollListener);
    _scrollController.dispose();
    _searchFocusNode.dispose();
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels >= 
        _scrollController.position.maxScrollExtent - 300 && 
        _hasMore && 
        !_isLoading) {
      _fetchAuctions();
    }
  }

  void _onSearchChanged() {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      // پێویست ناکات بپشکنیت ئەگەر بەتاڵە یان نا، چونکە _refresh هەموو حاڵەتەکان چارەسەر دەکات
      _refresh();
    });
  }

  Future<void> _fetchAuctions() async {
    if (_isLoading) return;
    setState(() => _isLoading = true);
    
    // **باشترکردنی ٢: ناردنی فلتەری زیادکراوەکانی ڕاستەوخۆ بۆ API**
    final paginatedData = await _apiService.getAuctions(
      page: _currentPage, 
      searchTerm: _searchController.text, 
      categoryId: _selectedCategoryId,
  
      limit: 10
    );
    
    if (paginatedData != null && mounted) {
      final List<dynamic> auctionData = paginatedData['data'] as List? ?? [];
      final List<Auction> newAuctions = auctionData.map((d) => Auction.fromJson(d)).toList();
      setState(() {
        _auctions.addAll(newAuctions);
        _currentPage++;
        _hasMore = newAuctions.isNotEmpty && newAuctions.length == 10;
        _isLoading = false;
        _isFirstLoad = false;
      });
    } else if (mounted) {
      setState(() {
        _isLoading = false;
        _isFirstLoad = false;
        _hasMore = false;
      });
    }
  }

  Future<void> _refresh() async {
    setState(() {
      _auctions = [];
      _currentPage = 1;
      _hasMore = true;
      _isFirstLoad = true;
    });
    // لێرەدا پێویستە await بەکاربهێنیت بۆ ئەوەی دڵنیابیتەوە کە داتاکان بە تەواوی بارکراون
    await _fetchAuctions();
  }

  void _startSearch() {
    setState(() => _isSearching = true);
    WidgetsBinding.instance.addPostFrameCallback((_) => _searchFocusNode.requestFocus());
  }
  
  void _stopSearch() {
    _searchFocusNode.unfocus();
    // دڵنیابە لەوەی کۆنترۆڵەرەکە بەتاڵ دەکەیتەوە پێش refresh
    if (_searchController.text.isNotEmpty) {
      _searchController.clear();
      setState(() {
        _isSearching = false;
      });
      _refresh();
    } else {
      setState(() {
        _isSearching = false;
      });
    }
  }

  void _toggleLiveFilter() {
    setState(() {
      _showLiveOnly = !_showLiveOnly;
    });
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            _buildSliverAppBar(),
          ];
        },
        body: RefreshIndicator(
          onRefresh: _refresh,
          child: _buildBody(),
        ),
      ),
    );
  }

  SliverAppBar _buildSliverAppBar() {
    final user = Provider.of<AuthProvider>(context, listen: false).user;
    final unreadCount = Provider.of<NotificationProvider>(context).unreadCount;
    
    return SliverAppBar(
      elevation: 0,
      toolbarHeight: 70,
      title: _isSearching 
          ? TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'گەڕان...', 
                border: InputBorder.none,
              ),
              style: const TextStyle(fontSize: 18),
            )
          : Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundImage: user?.profilePhotoUrl != null 
                      ? NetworkImage(user!.profilePhotoUrl!) 
                      : null,
                  child: user?.profilePhotoUrl == null 
                      ? const Icon(Icons.person, size: 20) 
                      : null,
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('بەخێربێیت 👋', style: Theme.of(context).textTheme.bodySmall),
                    Text(user?.name ?? 'میوان', 
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
      actions: _isSearching
          ? [IconButton(icon: const Icon(Icons.close), onPressed: _stopSearch)]
          : [
              IconButton(icon: const Icon(Icons.search), onPressed: _startSearch),
              IconButton(
                icon: Badge(
                  label: Text('$unreadCount'),
                  isLabelVisible: unreadCount > 0,
                  child: const Icon(Icons.notifications_none_outlined),
                ),
                onPressed: () { /* TODO */ },
              ),
              IconButton(
                icon: Icon(
                  _showLiveOnly ? Icons.live_tv : Icons.live_tv_outlined,
                  color: _showLiveOnly ? Colors.red : null,
                ),
                onPressed: _toggleLiveFilter,
              ),
            ],
      pinned: true,
      floating: true,
      forceElevated: true,
    );
  }

  Widget _buildBody() {
    if (_isFirstLoad) return _buildShimmerEffect();
    if (_auctions.isEmpty) return const Center(child: Text('هیچ زیادکراوەیەک نەدۆزرایەوە.'));
    
    return _isGridView
      ? MasonryGridView.builder(
          controller: _scrollController,
          padding: const EdgeInsets.all(5),
          gridDelegate: const SliverSimpleGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
          mainAxisSpacing: 1,
          crossAxisSpacing: 1,
          itemCount: _auctions.length + (_hasMore ? 1 : 0),
          itemBuilder: (context, index) {
            if (index == _auctions.length) return const Center(child: CircularProgressIndicator());
            return _buildGridAuctionCard(_auctions[index]);
          },
        )
      : ListView.builder(
          controller: _scrollController,
          padding: const EdgeInsets.all(1.0),
          itemCount: _auctions.length + (_hasMore ? 1 : 0),
          itemBuilder: (context, index) {
            if (index == _auctions.length) return const Padding(padding: EdgeInsets.all(16.0), child: Center(child: CircularProgressIndicator()));
            return _buildListAuctionCard(_auctions[index]);
          },
        );
  }

  Widget _buildListAuctionCard(Auction auction) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: CachedNetworkImage(
            imageUrl: auction.images.isNotEmpty ? auction.images.first.url : '',
            width: 56,
            height: 56,
            fit: BoxFit.cover,
            placeholder: (context, url) => Image.asset('assets/bid.png', fit: BoxFit.cover),
            errorWidget: (context, url, error) => Image.asset('assets/bid.png', fit: BoxFit.cover),
          ),
        ),
        title: Text(auction.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('نرخی ئێستا: ${NumberFormat.simpleCurrency().format(auction.currentPrice)}'),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => AuctionDetailScreen(auctionId: auction.id))).then((_) => _refresh()),
      ),
    );
  }

Widget _buildGridAuctionCard(Auction auction) {
  final theme = Theme.of(context);
  return GestureDetector(
    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => AuctionDetailScreen(auctionId: auction.id))).then((_) => _refresh()),
    child: Card(
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 1,
                child: CachedNetworkImage(
                  imageUrl: auction.images.isNotEmpty ? auction.images.first.url : '',
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Image.asset('assets/bid.png', fit: BoxFit.cover),
                  errorWidget: (context, url, error) => Image.asset('assets/bid.png', fit: BoxFit.cover),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      auction.title,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      NumberFormat.simpleCurrency().format(auction.currentPrice),
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: theme.colorScheme.secondary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          // **ستایلی باجی کات**
          Positioned(
            top: 8,
            left: 8,
            child: TimerBuilder.periodic(
              const Duration(seconds: 1),
              builder: (context) {
                final remaining = auction.endTime.difference(DateTime.now());
                if (remaining.isNegative) {
                  return const SizedBox.shrink(); // ئەگەر تەواو بوو، هیچی پیشان نادات
                }

                final timeColor = _getTimeColor(remaining);
                final isUrgent = remaining.inMinutes < 10;

                return Card(
                  color: timeColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                    child: Row(
                      children: [
                        // ئەگەر کاتەکە زۆر کەم بوو، ئایکۆنەکە دەلەرێتەوە
                        if (isUrgent)
                          TweenAnimationBuilder<double>(
                            tween: Tween(begin: 1.0, end: 1.2),
                            duration: const Duration(milliseconds: 500),
                            builder: (context, scale, child) => Transform.scale(scale: scale, child: child),
                            child: const Icon(Icons.timer_outlined, color: Colors.white, size: 14),
                          )
                        else
                           const Icon(Icons.timer_outlined, color: Colors.white, size: 14),

                        const SizedBox(width: 4),
                        Text(
                          _formatShortTime(remaining),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
}

// **فەنکشنی نوێ بۆ فۆرماتی کورتکراوەی کات**
String _formatShortTime(Duration d) {
  if (d.inDays > 0) return '${d.inDays}d ${d.inHours.remainder(24)}h';
  if (d.inHours > 0) return '${d.inHours}h ${d.inMinutes.remainder(60)}m';
  if (d.inMinutes > 0) return '${d.inMinutes}m ${d.inSeconds.remainder(60)}s';
  return '${d.inSeconds}s';
}

// (فەنکشنی _getTimeColor وەک خۆی بەکاربهێنە)
Color _getTimeColor(Duration remaining) {
  if (remaining.inHours > 1) return Colors.blue.shade700;
  if (remaining.inMinutes > 10) return Colors.amber.shade800;
  return Colors.red.shade600;
}
  Widget _buildShimmerEffect() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: MasonryGridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverSimpleGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        itemCount: 6,
        itemBuilder: (context, index) => Card(
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(height: 120, color: Colors.white),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(height: 16, width: double.infinity, color: Colors.white),
                    const SizedBox(height: 8),
                    Container(height: 14, width: 80, color: Colors.white),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}