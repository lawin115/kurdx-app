import 'package:flutter/material.dart';
import 'package:kurdpoint/screens/main_screen.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart'; // دڵنیابە ڕێڕەوەکە دروستە

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // کلیلێک بۆ فۆڕمەکە بۆ دڵنیابوونەوە لە داتاکان (validation)
  final _formKey = GlobalKey<FormState>();

  // کۆنترۆڵەر بۆ وەرگرتنی نووسینی ناو خانەکان
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  // گۆڕاوێک بۆ پیشاندانی بازنەی چاوەڕوانی
  bool _isLoading = false;

  @override
  void dispose() {
    // پاککردنەوەی کۆنترۆڵەرەکان بۆ ڕێگری لە memory leak
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // функцیایەک بۆ جێبەجێکردنی پڕۆسەی لۆگین
  Future<void> _submit() async {
    // دڵنیابوونەوە لەوەی داتای خانەکان بەپێی یاساکان دروستن
    if (!_formKey.currentState!.validate()) {
      return;
    }
    _formKey.currentState!.save();

    // گۆڕینی دۆخ بۆ پیشاندانی چاوەڕوانی
    setState(() {
      _isLoading = true;
    });

    try {
      // بانگکردنی функцیای لۆگین لە AuthProvider
      final success = await Provider.of<AuthProvider>(context, listen: false)
          .login(_emailController.text, _passwordController.text);
              if (success && mounted) {
      // Navigate to home screen after successful login
       Navigator.of(context).pushAndRemoveUntil(
    MaterialPageRoute(builder: (context) => const MainScreen()),
    (Route<dynamic> route) => false,
  );
    } else
            if (!success && mounted) {
        // ئەگەر لۆگین سەرکەوتوو نەبوو، پەیامێکی هەڵە پیشان بدە
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('ئیمەیڵ یان وشەی نهێنی هەڵەیە.'),
            backgroundColor: Colors.red,
          ),
        );
      }
      // ئەگەر سەرکەوتوو بوو، پێویست بە هیچ ناکات لێرە، چونکە `Consumer` لە `main.dart`
      // بە شێوەی ئۆتۆماتیکی بەکارهێنەر دەباتە لاپەڕەی سەرەکی.

    } catch (error) {
      // لە کاتی هەبوونی هەر هەڵەیەکی تر
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('هەڵەیەک ڕوویدا، تکایە دووبارە هەوڵبدەرەوە.'),
          backgroundColor: Colors.red,
        ),
      );
    }

    // گەڕاندنەوەی دۆخی چاوەڕوانی بۆ ئاسایی
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Card(
            elevation: 8.0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min, // بۆ ئەوەی کاردەکە بچووک بێتەوە
                  children: [
                    // لۆگۆی ئەپ یان ناونیشان
                    Icon(
                      Icons.gavel_rounded,
                      size: 60,
                      color: Theme.of(context).primaryColor,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'بەخێربێیتەوە!',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 24),

                    // خانەی ئیمەیڵ
                    TextFormField(
                      controller: _emailController,
                      decoration: const InputDecoration(
                        labelText: 'ئیمەیڵ',
                        prefixIcon: Icon(Icons.email),
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty || !value.contains('@')) {
                          return 'تکایە ئیمەیڵێکی دروست بنووسە.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // خانەی وشەی نهێنی
                    TextFormField(
                      controller: _passwordController,
                      decoration: const InputDecoration(
                        labelText: 'وشەی نهێنی',
                        prefixIcon: Icon(Icons.lock),
                        border: OutlineInputBorder(),
                      ),
                      obscureText: true, // بۆ شاردنەوەی نووسین
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'تکایە وشەی نهێنی بنووسە.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),

                    // دوگمەی چوونەژوورەوە
                    _isLoading
                        ? const CircularProgressIndicator() // پیشاندانی بازنەی چاوەڕوانی
                        : SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _submit,
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: const Text('چوونەژوورەوە'),
                            ),
                          ),
                    
                    // دوگمەی تۆمارکردن (بۆ ئاسانکاری)
                    TextButton(
                      onPressed: () {
                        // TODO: بەکارهێنەر بنێرە بۆ لاپەڕەی تۆمارکردن
                        // Navigator.of(context).pushNamed('/register');
                      }, 
                      child: const Text('هەژمارت نییە؟ یەکێک دروست بکە'),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}