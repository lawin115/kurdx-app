
import 'package:flutter/material.dart';
import '../models/notification_model.dart';
import '../services/api_service.dart';

class NotificationProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<NotificationModel> _notifications = [];
  int _unreadCount = 0;

  List<NotificationModel> get notifications => _notifications;
  int get unreadCount => _unreadCount;

  Future<void> fetchNotifications(String token) async {
    final fetchedNotifications = await _apiService.getNotifications(token);
    if (fetchedNotifications != null) {
      _notifications = fetchedNotifications;
      _unreadCount = _notifications.where((n) => !n.isRead).length;
      notifyListeners();
    }
  }

  Future<void> markAsRead(String notificationId, String token) async {
    final success = await _apiService.markNotificationAsRead(notificationId, token);
    if (success) {
      // لیستەکە نوێ بکەرەوە بۆ ئەوەی دۆخی خوێندنەوەکە بگۆڕدرێت
      await fetchNotifications(token);
    }
  }
}