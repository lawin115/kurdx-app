import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_animate/animate.dart';
import 'package:flutter_animate/effects/scale_effect.dart';
import 'package:flutter_animate/effects/shake_effect.dart';
import 'package:flutter_animate/effects/then_effect.dart';
import 'package:kurdpoint/models/bid_model.dart';
import 'package:provider/provider.dart';
import 'package:dart_pusher_channels/dart_pusher_channels.dart';
import 'package:intl/intl.dart';
import 'package:timer_builder/timer_builder.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:animate_do/animate_do.dart';
import 'package:shimmer/shimmer.dart';

import '../models/auction_model.dart';
import '../models/comment_model.dart';
import '../models/user_model.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import 'screens/login_screen.dart';

class AuctionDetailScreen extends StatefulWidget {
  final int auctionId;
  const AuctionDetailScreen({super.key, required this.auctionId});

  @override
  State<AuctionDetailScreen> createState() => _AuctionDetailScreenState();
}

class _AuctionDetailScreenState extends State<AuctionDetailScreen> {
  // --- Controllers, Services, etc. ---
  final ApiService _apiService = ApiService();
 final CarouselSliderController _carouselController = CarouselSliderController();

  final TextEditingController _bidController = TextEditingController();
  final TextEditingController _commentController = TextEditingController();
  late final FocusNode _commentFocusNode;

  // --- Data State ---
  Auction? _auction;
  String? _token;
  User? _currentUser;
  PusherChannelsClient? _pusherClient;

  // --- UI State ---
  bool _isLoading = true;
  bool _isPlacingBid = false;
  bool _isAuctionActive = true;
  int _currentImageIndex = 0;
  int? _replyToCommentId;
  bool _isRetryingConnection = false;
  final GlobalKey _priceKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _commentFocusNode = FocusNode();
    final auth = Provider.of<AuthProvider>(context, listen: false);
    _token = auth.token;
    _currentUser = auth.user;
    _fetchAuctionDetails();
    _initPusher();
  }

  @override
  void dispose() {
    _pusherClient?.disconnect();
    _bidController.dispose();
    _commentController.dispose();
    _commentFocusNode.dispose();
    super.dispose();
  }

  // --- Logic Methods ---

  Future<void> _fetchAuctionDetails({bool showLoading = true}) async {
    if (showLoading && mounted) setState(() => _isLoading = true);
    final fetchedAuction = await _apiService.getAuctionDetails(widget.auctionId, _token);
    if (mounted) {
      setState(() {
        _auction = fetchedAuction;
        _isLoading = false;
        if (_auction != null) {
          _isAuctionActive = DateTime.now().isBefore(_auction!.endTime);
        }
      });
    }
  }
  
  Future<void> _initPusher() async {
    if (_isRetryingConnection) return;
    _isRetryingConnection = true;
    try {
      const String laravelHost = "192.168.1.25"; // <-- IPی خۆت دابنێ
      const String reverbPort = "8080";
      const String appKey = "qmkcqfx960e6h7q00qdp"; // REVERB_APP_KEY
      final String channelName = 'auction.${widget.auctionId}';

      final hostOptions = PusherChannelsOptions.fromHost(scheme: 'ws', host: laravelHost, port: int.parse(reverbPort), key: appKey);
      _pusherClient = PusherChannelsClient.websocket(
        options: hostOptions,
        connectionErrorHandler: (_, __, refresh) => refresh(),
      );
      
      final channel = _pusherClient!.publicChannel(channelName);
      
      channel.bind('BidPlaced').listen((event) {
        if (mounted && event.data != null) {
          try {
            final eventData = jsonDecode(event.data!);
            setState(() {
              _auction = _auction!.copyWith(
                currentPrice: double.parse(eventData['current_price'].toString()),
                bids: [Bid.fromJson(eventData['latest_bid']), ..._auction!.bids],
              );
              _carouselController.animateToPage(_currentImageIndex);
            });
          } catch (e) { print("Error parsing BidPlaced: $e"); _fetchAuctionDetails(showLoading: false); }
        }
      });
      
      channel.bind('AuctionTimeExtended').listen((event) {
         if (mounted && event.data != null && _auction != null) {
           try {
             final eventData = jsonDecode(event.data!);
             setState(() => _auction = _auction!.copyWith(endTime: DateTime.parse(eventData['newEndTime']['date'])));
           } catch (e) { print("Error parsing TimeExtended: $e"); }
         }
      });

      _pusherClient!.onConnectionEstablished.listen((_) => channel.subscribe());
      await _pusherClient!.connect();
      _isRetryingConnection = false;
    } catch (e) {
      _retryConnection();
    }
  }

  void _retryConnection() {
    if (mounted) {
      Future.delayed(const Duration(seconds: 5), () {
        if (mounted) {
          _isRetryingConnection = false;
          _initPusher();
        }
      });
    }
  }

  Future<void> _placeBid() async {
     if (_isPlacingBid || _bidController.text.trim().isEmpty) return;
     if (_token == null) {
       _navigateToLogin();
       return;
     }
     final highestBidder = _auction?.bids.isNotEmpty == true ? _auction!.bids.first.user : null;
     if (highestBidder?.id == _currentUser?.id) {
       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تۆ پێشتر بەرزترین نرخت داناوە!'), backgroundColor: Colors.orange));
       return;
     }
     setState(() => _isPlacingBid = true);
     final success = await _apiService.placeBid(widget.auctionId, _bidController.text, _token!);
     if (mounted) {
       if (success) {
         _bidController.clear();
         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نرخەکەت بە سەرکەوتوویی زیادکرا!'), backgroundColor: Colors.green));
       } else {
         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هەڵەیەک ڕوویدا، نرخەکەت بەرزتر بکە.'), backgroundColor: Colors.red));
       }
       setState(() => _isPlacingBid = false);
     }
  }

  Future<void> _postComment() async {
    final commentBody = _commentController.text.trim();
    if (commentBody.isEmpty || _token == null) return;
    _commentFocusNode.unfocus();
    final tempBody = _commentController.text;
    _commentController.clear();
    final newComment = await _apiService.postComment(widget.auctionId, tempBody, _replyToCommentId, _token!);
    if (mounted) {
      if (newComment != null) {
        _fetchAuctionDetails(showLoading: false);
        setState(() => _replyToCommentId = null);
      } else {
        setState(() => _commentController.text = tempBody);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ناردنی کۆمێنت سەرکەوتوو نەبوو'), backgroundColor: Colors.red));
      }
    }
  }
  
  void _toggleWatchlist() {
    Provider.of<AuthProvider>(context, listen: false).toggleWatchlist(_auction!.id);
  }

  void _shareAuction() {
    final String auctionUrl = "https://kurd.bids/auctions/${_auction!.id}";
    final String shareText = "سەیری ئەم مەزادە بکە: '${_auction!.title}'!\nنرخی ئێستا: \$${_auction!.currentPrice}\n$auctionUrl";
    Share.share(shareText);
  }

  void _navigateToLogin() {
    Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => const LoginScreen()));
  }

  // --- Build Method ---
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: BackButton(color: _auction?.images.isNotEmpty == true ? Colors.white : Colors.black),
        actions: [
          if (_auction != null) ...[
            IconButton(icon: Icon(Icons.share, color: _auction!.images.isNotEmpty ? Colors.white : Colors.black), onPressed: _shareAuction),
            Consumer<AuthProvider>(
              builder: (context, auth, child) => IconButton(
                icon: Icon(
                  auth.isInWatchlist(_auction!.id) ? Icons.favorite : Icons.favorite_border,
                  color: _auction!.images.isNotEmpty ? Colors.white : Colors.red,
                ),
                onPressed: _toggleWatchlist,
              ),
            ),
          ]
        ],
      ),
      body: _isLoading
          ? _buildLoadingShimmer()
          : _auction == null
              ? _buildErrorState()
              : Column(
                  children: [
                    Expanded(
                      child: CustomScrollView(
                        slivers: [
                          SliverToBoxAdapter(child: _buildImageGallery()),
                          SliverToBoxAdapter(child: _buildMainInfoSection()),
                          SliverPadding(
                            padding: const EdgeInsets.symmetric(horizontal: 16.0),
                            sliver: _buildBidHistoryList(),
                          ),
                          SliverToBoxAdapter(child: _buildCommentSection()),
                        ],
                      ),
                    ),
                    _buildBidArea(),
                  ],
                ),
    );
  }

  // --- UI Helper Widgets ---

Widget _buildImageGallery() {
  if (_auction!.images.isEmpty) {
    return Container(
      height: 250,
      color: Colors.grey[300],
      child: const Icon(Icons.image_not_supported, size: 80, color: Colors.grey),
    );
  }

  return Stack(
    alignment: Alignment.bottomCenter,
    children: [
      CarouselSlider(
        carouselController: _carouselController, // Link the controller to the carousel
        options: CarouselOptions(
          height: 300,
          viewportFraction: 1.0,
          initialPage: 0, // Set the initial page if required
          onPageChanged: (index, reason) => setState(() => _currentImageIndex = index), // Update index
        ),
        items: _auction!.images.map((image) {
          return CachedNetworkImage(
            imageUrl: image.url, // Assuming image has 'url' attribute
            fit: BoxFit.cover,
            width: double.infinity,
            placeholder: (context, url) => Shimmer.fromColors(
              baseColor: Colors.grey[300]!,
              highlightColor: Colors.grey[100]!,
              child: Container(color: Colors.grey[200]),
            ),
            errorWidget: (context, url, error) => const Icon(Icons.error),
          );
        }).toList(),
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: _auction!.images.asMap().entries.map((entry) {
          return GestureDetector(
            onTap: () => _carouselController.animateToPage(entry.key), // Navigate to the tapped image
            child: Container(
              width: 10.0,
              height: 10.0,
              margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(_currentImageIndex == entry.key ? 0.9 : 0.4),
              ),
            ),
          );
        }).toList(),
      ),
    ],
  );
}

  Widget _buildMainInfoSection() {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FadeInUp(delay: const Duration(milliseconds: 100), child: Text(_auction!.title, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold))),
          const SizedBox(height: 8),
          FadeInUp(delay: const Duration(milliseconds: 200), child: Text(_auction!.description, style: theme.textTheme.bodyLarge?.copyWith(color: Colors.grey[700], height: 1.5))),
          FadeInUp(delay: const Duration(milliseconds: 300), child: _buildVendorInfoCard()),
          FadeInUp(delay: const Duration(milliseconds: 400), child: _buildAuctionInfoCard()),
          const SizedBox(height: 16),
          const Divider(),
        ],
      ),
    );
  }

  Widget _buildAuctionInfoCard() {
    final theme = Theme.of(context);
    final formatCurrency = NumberFormat.simpleCurrency(locale: 'en_US', decimalDigits: 2);
    final highestBidder = _auction!.bids.isNotEmpty ? _auction!.bids.first.user : null;
    final isCurrentUserHighest = highestBidder?.id == _currentUser?.id;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 16.0),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('نرخی ئێستا', style: TextStyle(color: Colors.grey)),
                    const SizedBox(height: 4),
                    Animate(
                      key: _priceKey,
                      effects: const [ShakeEffect(duration: Duration(milliseconds: 500), hz: 4), ThenEffect(), ScaleEffect(duration: Duration(milliseconds: 300), curve: Curves.easeIn)],
                      child: Text(formatCurrency.format(_auction!.currentPrice), style: theme.textTheme.headlineSmall?.copyWith(color: theme.primaryColor, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                if (highestBidder != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: isCurrentUserHighest ? Colors.green.shade100 : Colors.amber.shade100, borderRadius: BorderRadius.circular(20)),
                    child: Row(
                      children: [
                        Icon(isCurrentUserHighest ? Icons.star : Icons.emoji_events, color: isCurrentUserHighest ? Colors.green.shade700 : Colors.amber.shade800, size: 16),
                        const SizedBox(width: 6),
                        Text(isCurrentUserHighest ? 'تۆ براوەیت' : '${highestBidder.name}', style: TextStyle(fontWeight: FontWeight.bold, color: isCurrentUserHighest ? Colors.green.shade800 : Colors.amber.shade900)),
                      ],
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(height: 1),
            const SizedBox(height: 16),
            TimerBuilder.periodic(
              const Duration(seconds: 1),
              builder: (context) {
                final now = DateTime.now();
                if (now.isAfter(_auction!.endTime)) {
                  WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted && _isAuctionActive) setState(() => _isAuctionActive = false); });
                  return _buildEndedBadge(theme);
                }
                final remaining = _auction!.endTime.difference(now);
                return _buildCountdownTimer(remaining, theme);
              },
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildCountdownTimer(Duration remaining, ThemeData theme) {
    return Column(
      children: [
        const Text('کاتی ماوە', style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildTimeUnit('رۆژ', remaining.inDays, theme),
            _buildTimeUnit('کاتژمێر', remaining.inHours.remainder(24), theme),
            _buildTimeUnit('خولەک', remaining.inMinutes.remainder(60), theme),
            _buildTimeUnit('چرکە', remaining.inSeconds.remainder(60), theme),
          ],
        ),
      ],
    );
  }

  Widget _buildTimeUnit(String label, int value, ThemeData theme) {
    return Column(
      children: [
        Text(value.toString().padLeft(2, '0'), style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ],
    );
  }

  Widget _buildEndedBadge(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(color: Colors.red.shade100, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.timer_off, size: 18, color: Colors.red.shade800),
          const SizedBox(width: 8),
          Text('مەزاد کۆتایی هات', style: TextStyle(color: Colors.red.shade800, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildVendorInfoCard() {
    final vendor = _auction!.user;
    if (vendor == null) return const SizedBox.shrink();
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            CircleAvatar(radius: 25, backgroundImage: vendor.profilePhotoUrl != null ? NetworkImage(vendor.profilePhotoUrl!) : null, child: vendor.profilePhotoUrl == null ? const Icon(Icons.store) : null),
            const SizedBox(width: 12),
            Expanded(child: Text(vendor.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
            OutlinedButton(onPressed: () {}, child: const Text('پرۆفایل')),
          ],
        ),
      ),
    );
  }

  Widget _buildBidHistoryList() {
    if (_auction!.bids.isEmpty) {
      return SliverToBoxAdapter(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 48),
          alignment: Alignment.center,
          child: Column(
            children: [
              Icon(Icons.history_toggle_off, size: 60, color: Colors.grey[400]),
              const SizedBox(height: 16),
              const Text('هێشتا هیچ نرخێک زیادنەکراوە', style: TextStyle(fontSize: 16, color: Colors.grey)),
              const Text('یەکەم کەس بە!', style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      );
    }
    return SliverList.separated(
      itemCount: _auction!.bids.length,
      itemBuilder: (context, index) {
        final bid = _auction!.bids[index];
        final isCurrentUser = bid.user?.id == _currentUser?.id;
        return ListTile(
          leading: CircleAvatar(backgroundImage: bid.user?.profilePhotoUrl != null ? NetworkImage(bid.user!.profilePhotoUrl!) : null, child: bid.user?.profilePhotoUrl == null ? Text(bid.user?.name[0].toUpperCase() ?? '?') : null),
          title: Text(bid.user?.name ?? 'بەکارهێنەری سڕاوە', style: TextStyle(fontWeight: isCurrentUser == true ? FontWeight.bold : FontWeight.normal)),
          subtitle: Text(DateFormat('MMM d, h:mm a').format(bid.createdAt)),
          trailing: Text(NumberFormat.simpleCurrency().format(bid.amount), style: TextStyle(fontWeight: FontWeight.bold, color: isCurrentUser == true ? Theme.of(context).primaryColor : null)),
        );
      },
      separatorBuilder: (context, index) => const Divider(indent: 70),
    );
  }

  Widget _buildCommentSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // فۆڕمی زیادکردنی کۆمێنتی نوێ
        if (_token != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      focusNode: _commentFocusNode,
                      controller: _commentController,
                      decoration: const InputDecoration(hintText: "پرسیارێکت بنووسە..."),
                    ),
                  ),
                  
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: () => _postComment(),
                  )
                ],
              ),
            ),
          ),
        const SizedBox(height: 16),
        
        // لیستی کۆمێنتەکان
   if (_auction!.comments.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 32.0),
            child: Center(child: Text("هێشتا هیچ پرسیارێک نەکراوە. یەکەم کەس بە!")),
          )
        else
          // ===== چارەسەرەکە لێرەدایە =====
          // بەکارهێنانی Column لە جیاتی ListView بۆ ناو SingleChildScrollView
          Column(
            children: _auction!.comments.map((comment) => _buildCommentItem(comment)).toList(),
          )
      ],
    );
  }

Widget _buildCommentItem(Comment comment) {
  return Card(
    margin: const EdgeInsets.symmetric(vertical: 6.0),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundImage: comment.user.profilePhotoUrl != null
                    ? NetworkImage(comment.user.profilePhotoUrl!)
                    : null,
                child: comment.user.profilePhotoUrl == null
                    ? Text(comment.user.name[0].toUpperCase())
                    : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(comment.user.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(
                      DateFormat('MMM d, yyyy').format(comment.createdAt),
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: () {
                  setState(() {
                    _replyToCommentId = comment.id;
                    _commentFocusNode.requestFocus(); // فۆکەس بخەرە سەر TextField
                  });
                },
                child: const Text("وەڵام"),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 52.0, top: 8.0, bottom: 8.0),
            child: Text(comment.body),
          ),
          
          // پیشاندانی وەڵامەکان (replies)
          if (comment.replies.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(left: 40.0, top: 8.0),
              child: Column(
                // بەکارهێنانی recursive بۆ پیشاندانی وەڵامی وەڵامەکان
                children: comment.replies.map((reply) => _buildCommentItem(reply)).toList(),
              ),
            )
        ],
      ),
    ),
  );
}
  Widget _buildBidArea() {
     final isOwner = _auction?.user?.id == _currentUser?.id;
    if (!_isAuctionActive) return _buildEndedBadge(Theme.of(context));
  // lib/screens/auction_detail_screen.dart -> _buildBidArea()

if (isOwner) {
  return Container(
    margin: const EdgeInsets.all(16.0), // بۆشایی لە دەوروبەری
    padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 16.0),
    
    // ===== چارەسەرەکە لێرەدایە =====
    decoration: BoxDecoration(
      color: Colors.blue.shade50, // ڕەنگ لەناو decoration دادەنرێت
      borderRadius: BorderRadius.circular(16), // borderRadius لێرەدا دروستە
      border: Border.all(color: Colors.blue.shade200) // چوارچێوەیەکی جوان
    ),
    
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.info_outline, color: Colors.blue.shade700),
        const SizedBox(width: 12),
        const Text(
          "تۆ خاوەنی ئەم مەزادەیت",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
      ],
    ),
  );
}
    if (_token == null) {
      return Padding(
        padding: const EdgeInsets.all(16.0),
        child: FilledButton(onPressed: _navigateToLogin, child: const Text('بچۆ ژوورەوە بۆ زیادکردنی نرخ')),
      );
    }
    return _buildBidInputArea();
  }

  Widget _buildBidInputArea() {
    final highestBidder = _auction?.bids.isNotEmpty == true ? _auction!.bids.first.user : null;
    final isCurrentUserHighest = highestBidder?.id == _currentUser?.id;
    return Material(
      elevation: 10,
      child: Container(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isCurrentUserHighest)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.verified, size: 18, color: Colors.green), const SizedBox(width: 8), Text("تۆ براوەی ئێستایت!", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))]),
              ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _bidController,
                    enabled: !isCurrentUserHighest,
                    decoration: InputDecoration(
                      labelText: isCurrentUserHighest ? 'ناتوانیت نرخ زیاد بکەیت' : 'نرخی خۆت بنووسە',
                      prefixText: '\$ ',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 12),
                FilledButton.tonal(
                  onPressed: isCurrentUserHighest ? null : _placeBid,
                  style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)),
                  child: _isPlacingBid ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.gavel),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Container(
            height: 280,
            color: Colors.grey[200],
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              Container(
                height: 200,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              const SizedBox(height: 24),
              Container(
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              const SizedBox(height: 24),
              Container(
                height: 120,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ]),
          ),
        ),
      ],
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 48, color: Theme.of(context).colorScheme.error),
          const SizedBox(height: 16),
          Text(
            'Failed to load auction',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: _fetchAuctionDetails,
            icon: const Icon(Icons.refresh),
            label: const Text('Try Again'),
          ),
        ],
      ),
    );
  }
}

extension on CarouselController {
  void animateToPage(int key) {}
}