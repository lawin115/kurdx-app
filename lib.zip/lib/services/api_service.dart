// lib/services/api_service.dart

import 'dart:convert';
import 'dart:io'; // بۆ بەکارهێنانی File
import 'package:http/http.dart' as http;
import 'package:kurdpoint/models/category_model.dart';
import 'package:kurdpoint/models/comment_model.dart';
import 'package:kurdpoint/models/notification_model.dart';
import 'package:kurdpoint/models/order_model.dart';
import '../models/auction_model.dart';
import '../models/user_model.dart';

class ApiService {
  // تکایە دڵنیابە ئەمە IP دروستەکەیە
  final String _baseUrl = "http://192.168.1.25:8000/api";

  // ===== функцیای یەکەم: وەرگرتنی هەموو مەزادەکان =====
// lib/services/api_service.dart


Future<Auction?> createAuction({
  required String token,
  required Map<String, String> data,
  required List<File> images, // <-- گۆڕدرا بۆ لیستی فایل

}) async {
  final url = Uri.parse("$_baseUrl/auctions");
  try {
    var request = http.MultipartRequest('POST', url);

    // Add headers
    request.headers['Authorization'] = 'Bearer $token';
    request.headers['Accept'] = 'application/json';

    // Add form fields (auction data)
    request.fields.addAll(data);

    // Check if image file is provided
      for (var i = 0; i < images.length; i++) {
      // Add image file to the request
      request.files.add(await http.MultipartFile.fromPath('images[]', images[i].path));
    } 

    // Send request
    var response = await request.send();

    if (response.statusCode == 201) { // Created successfully
      final responseBody = await response.stream.bytesToString();
      return Auction.fromJson(json.decode(responseBody));
    } else {
      final responseBody = await response.stream.bytesToString();
      print("Failed to create auction: $responseBody");
    }
  } catch (e) {
    print("Error in createAuction: $e");
  }
  return null;
} Future<Map<String, dynamic>?> getAuctions({required int page, String? searchTerm, String? filter, int? categoryId, required int limit}) async {
 
  // دروستکردنی پارامەترەکان
  final Map<String, String> queryParameters = {
    'page': page.toString(),
  };
  if (categoryId != null) {
      queryParameters['category'] = categoryId.toString();
    }
  // ئەگەر searchTerm بوونی هەبوو و بەتاڵ نەبوو، زیادی بکە بۆ پارامەترەکان
  if (searchTerm != null && searchTerm.isNotEmpty) {
    queryParameters['search'] = searchTerm;
  }

  if (searchTerm != null && searchTerm.isNotEmpty) {
    queryParameters['search'] = searchTerm;
  }
  if (filter != null && filter != 'latest') { // 'latest' دۆخی بنەڕەتییە و پێویست بە ناردن ناکات
    queryParameters['filter'] = filter;
  }

  final url = Uri.parse("$_baseUrl/auctions").replace(queryParameters: queryParameters);
  // دروستکردنی لینکی کۆتایی لەگەڵ هەموو پارامەترەکان
  
  
  print("Fetching auctions from: $url"); // ئەم printـە ئێستا لینکی دروست پیشان دەدات

  try {
    final response = await http.get(
      url,
      headers: {'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 15));

    print("Paginated auctions response status: ${response.statusCode}");
    
    if (response.statusCode == 200) {
      return json.decode(response.body) as Map<String, dynamic>;
    }
  } catch (e) {
    print("!!! ERROR in paginated getAuctions: ${e.toString()}");
  }

  return null;
}

Future<List<Order>?> getMyOrders(String token) async {
  final url = Uri.parse("$_baseUrl/profile/orders");
  try {
    final response = await http.get(url, headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((d) => Order.fromJson(d)).toList();
    }
  } catch (e) { /* ... */ }
  return null;
}
Future<List<NotificationModel>?> getNotifications(String token) async {
  final url = Uri.parse("$_baseUrl/notifications");
  try {
    final response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'},
    );
    if (response.statusCode == 200) {
      final Map<String, dynamic> paginatedData = json.decode(response.body);
      final List<dynamic> data = paginatedData['data'];
      return data.map((d) => NotificationModel.fromJson(d)).toList();
    }
  } catch (e) { print("Error getting notifications: $e"); }
  return null;
}

// نیشانکردنی ئاگادارکردنەوە وەک خوێندراوە
Future<bool> markNotificationAsRead(String notificationId, String token) async {
  final url = Uri.parse("$_baseUrl/notifications/$notificationId/mark-as-read");
  try {
    final response = await http.post(
      url,
      headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'},
    );
    return response.statusCode == 204; // 204 No Content
  } catch (e) { return false; }
}

Future<User?> updateUserProfile({
  required String token,
  required String name,
  required String email,
  File? photoFile,
}) async {
  final url = Uri.parse("$_baseUrl/profile/update");
  try {
    var request = http.MultipartRequest('POST', url);
    request.headers['Authorization'] = 'Bearer $token';
    request.headers['Accept'] = 'application/json';

    request.fields['name'] = name;
    request.fields['email'] = email;
    
    if (photoFile != null) {
      request.files.add(await http.MultipartFile.fromPath('photo', photoFile.path));
    }

    var response = await request.send();
    final responseBody = await response.stream.bytesToString();
    
    if (response.statusCode == 200) {
      return User.fromJson(json.decode(responseBody));
    } else {
      print("Failed to update profile: $responseBody");
    }
  } catch (e) {
    print("Error in updateUserProfile: $e");
  }
  return null;
}

Future<Comment?> postComment(int auctionId, String body, int? parentId, String token) async {
  final url = Uri.parse("$_baseUrl/auctions/$auctionId/comments");
  try {
    final response = await http.post(
      url,
      headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json', 'Content-Type': 'application/json'},
      body: json.encode({'body': body, 'parent_id': parentId}),
    );
    if (response.statusCode == 201) {
      return Comment.fromJson(json.decode(response.body));
    }
  } catch (e) { /* ... */ }
  return null;
}

Future<List<Category>?> getCategories() async {
  final url = Uri.parse("$_baseUrl/categories");
  try {
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((d) => Category.fromJson(d)).toList();
    }
  } catch (e) { /* ... */ }
  return null;
}

  // ===== функцیای دووەم: وەرگرتنی زانیاری یەک مەزاد =====
  Future<Auction?> getAuctionDetails(int id, String? token) async { // <-- String? token زیاد بکە
  final url = Uri.parse("$_baseUrl/auctions/$id");
  try {
    // ===== چارەسەرەکە لێرەدایە: زیادکردنی Header =====
    final response = await http.get(
      url,
      headers: {
        'Accept': 'application/json',
        // ئەگەر تۆکن هەبوو، بینێرە
        if (token != null) 'Authorization': 'Bearer $token', 
      },
    ).timeout(const Duration(seconds: 15));
    
    if (response.statusCode == 200) {
      return Auction.fromJson(json.decode(response.body));
    }
  } catch (e) {
    print("Error in getAuctionDetails: $e");
  }
  return null;
}
Future<Map<String, dynamic>?> getMyActivity(String token) async {
  final url = Uri.parse("$_baseUrl/profile/activity");
  print("Fetching user activity from: $url"); // -- بۆ تێست

  try {
    final response = await http.get(
      url,
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      },
    ).timeout(const Duration(seconds: 15));

    print("getMyActivity response status: ${response.statusCode}"); // -- بۆ تێست
    print("getMyActivity response body: ${response.body}"); // -- بۆ تێست

    if (response.statusCode == 200) {
      print("Successfully fetched activity."); // -- بۆ تێست
      return json.decode(response.body);
    }
  } catch (e) {
    print("!!! FATAL ERROR in getMyActivity: ${e.toString()}"); // -- بۆ تێست
  }
  
  print("getMyActivity failed and returned null."); // -- بۆ تێست
  return null;
}

Future<bool> toggleWatchlist(int auctionId, String token) async {
  final url = Uri.parse("$_baseUrl/auctions/$auctionId/toggle-watchlist");
  try {
    final response = await http.post(
      url,
      headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'},
    );
    return response.statusCode == 200;
  } catch (e) {
    return false;
  }
}

Future<List<Auction>?> getWatchlist(String token) async {
  final url = Uri.parse("$_baseUrl/watchlist");
  try {
    final response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'},
    );
    if (response.statusCode == 200) {
      return auctionFromJson(response.body);
    }
  } catch (e) {
    // ...
  }
  return null;
}
  // ===== функцیای سێیەم: زیادکردنی نرخ =====
  Future<bool> placeBid(int auctionId, String amount, String token) async {
    final url = Uri.parse("$_baseUrl/auctions/$auctionId/bids");
    print("Placing bid for auction ID $auctionId with amount $amount");

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode({'amount': amount}),
      ).timeout(const Duration(seconds: 15));
      
      print("Place bid response status: ${response.statusCode}");
      print("Place bid response body: ${response.body}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      }
    } catch (e) {
      print("!!! ERROR in placeBid: ${e.toString()}");
    }
    return false;
  }

 Future<Map<String, dynamic>?> login(String email, String password) async {
  final url = Uri.parse("$_baseUrl/login");
  try {
    final response = await http.post(
      url,
      headers: {'Accept': 'application/json'},
      body: {'email': email, 'password': password},
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
  } catch (e) {
    print("Error in login service: $e");
  }
  return null;
}





Future<List<Order>?> getSoldAuctions(String token) async {
  final url = Uri.parse("$_baseUrl/profile/sold");
  try {
    final response = await http.get(url, headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((d) => Order.fromJson(d)).toList();
    }
  } catch (e) { /* ... */ }
  return null;
}














Future<bool> updateFCMToken(String fcmToken, String apiToken) async {
  final url = Uri.parse("$_baseUrl/fcm-token");
  print("--- Sending FCM Token to Server: $fcmToken ---");
  try {
    final response = await http.post(
      url,
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer $apiToken',
      },
      body: {'fcm_token': fcmToken},
    );
    
    if (response.statusCode == 200) {
      print("--- FCM Token updated successfully on server. ---");
      return true;
    } else {
      print("--- Failed to update FCM Token on server. Status: ${response.statusCode}, Body: ${response.body} ---");
    }
  } catch (e) {
    print("!!! ERROR sending FCM token: $e");
  }
  return false;
}

}