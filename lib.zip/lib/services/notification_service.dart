// lib/services/notification_service.dart
import 'package:firebase_messaging/firebase_messaging.dart';
import './api_service.dart'; // importـی سێرڤیسەکەی خۆت

class NotificationService {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final ApiService _apiService = ApiService(); // نموونەیەک لە سێرڤیس

  Future<void> initNotifications() async {
    // داواکردنی ڕێگەپێدان
    await _firebaseMessaging.requestPermission();

    // وەرگرتنی تۆکن
    final fcmToken = await _firebaseMessaging.getToken();
    print("==== FCM Token: $fcmToken ====");
    
    // TODO: تۆکنەکە بۆ سێرڤەر بنێرە
    // await sendTokenToServer(fcmToken);

    // گوێگرتن لە نوێبوونەوەی تۆکن
    _firebaseMessaging.onTokenRefresh.listen((newToken) {
      // TODO: تۆکنە نوێیەکە بۆ سێرڤەر بنێرە
      // await sendTokenToServer(newToken);
    });
  }

  // TODO: функцIAیەک زیاد بکە بۆ ناردنی تۆکن بۆ سێرڤیس
  // Future<void> sendTokenToServer(String? token, String? authToken) async {
  //   if (token != null && authToken != null) {
  //     await _apiService.updateFCMToken(token, authToken);
  //   }
  // }
}