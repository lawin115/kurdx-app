import 'package:flutter/material.dart';
import 'package:kurdpoint/providers/notification_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import './providers/auth_provider.dart';
import './providers/theme_provider.dart'; // <-- importـی ThemeProvider
import './screens/login_screen.dart';
import './screens/main_screen.dart';
import './screens/splash_screen.dart';
import './screens/onboarding_screen.dart';
import './firebase_options.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  print("Handling a background message: ${message.messageId}");
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  
  final prefs = await SharedPreferences.getInstance();
  final bool seenOnboarding = prefs.getBool('seenOnboarding') ?? false;

  runApp(
    // ===== چارەسەرەکە لێرەدایە: بەکارهێنانی MultiProvider =====
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (ctx) => AuthProvider()),
        ChangeNotifierProvider(create: (ctx) => ThemeProvider()), // <-- ThemeProvider لێرە زیادکرا
        ChangeNotifierProvider(create: (ctx) => NotificationProvider()),
      ],
      child: MyApp(seenOnboarding: seenOnboarding),
    ),
  );
}

class MyApp extends StatelessWidget {
  final bool seenOnboarding;
  const MyApp({super.key, required this.seenOnboarding});

  @override
  Widget build(BuildContext context) {
    // گوێگرتن لە گۆڕانکارییەکانی ThemeProvider
    final themeProvider = Provider.of<ThemeProvider>(context);

    return MaterialApp(
      title: 'Kurd Bids',
      debugShowCheckedModeBanner: false, // لابردنی "Debug" banner

      // ===== گۆڕانکاری گرنگ بۆ Theme لێرەدایە =====
      themeMode: themeProvider.themeMode,
      
      // --- دیزاینی تیمی ڕووناک (Light Mode) ---
      theme: ThemeData(
        brightness: Brightness.light,
        fontFamily: 'Poppins', // فۆنتی نوێ
        primaryColor: const Color(0xFF1A1A1A), // ڕەنگی ڕەشی سەرەکی
        scaffoldBackgroundColor: const Color(0xFFF5F5F7), // ڕەنگی پاشبنەمای خۆڵەمێشی
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF1A1A1A),
          secondary: Color(0xFF5E5CE6), // ڕەنگی شینی مۆر
          background: Color(0xFFF5F5F7),
        ),
        cardTheme: CardThemeData(
          elevation: 1,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 16),
          )
        )
      ),
      
      // --- دیزاینی تیمی تاریک (Dark Mode) ---
    darkTheme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'Poppins',
        primaryColor: Colors.white,
        scaffoldBackgroundColor: const Color(0xFF1C1C1E),
        colorScheme: const ColorScheme.dark(
          primary: Colors.white,
          secondary: Color(0xFF5E5CE6),
          background: Color(0xFF1C1C1E),
          surface: Color(0xFF2C2C2E),
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          color: const Color(0xFF2C2C2E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF5E5CE6),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 16),
          )
        )
      ),
      // بەکارهێنانی Consumer بۆ گوێگرتن لە گۆڕانکارییەکانی لۆگین
      home: Consumer<AuthProvider>(
        builder: (ctx, auth, _) {
          // ئەگەر بەکارهێنەر لۆگین بوو، بچۆ بۆ لاپەڕەی سەرەکی
          if (auth.isLoggedIn) {
            return const MainScreen();
          }
          
          // ئەگەر لۆگین نەبوو، هەوڵی لۆگینی ئۆتۆماتیکی بدە
          // FutureBuilder تەنها یەکجار کاردەکات
          return FutureBuilder(
            future: auth.tryAutoLogin(),
            builder: (ctx, authResultSnapshot) {
              // کاتێک چاوەڕێی وەڵامی tryAutoLoginـە
              if (authResultSnapshot.connectionState == ConnectionState.waiting) {
                return const SplashScreen(); // لاپەڕەی چاوەڕوانی پیشان بدە
              }
              // ئەگەر دوای هەوڵدان، هێشتا لۆگین نەبووبوو، بچۆ بۆ لاپەڕەی لۆگین
              // (ئەگەر سەرکەوتوو بوو، isLoggedIn دەبێتە true و ifـی سەرەوە کاردەکات)
              return const LoginScreen();
            },
          );
        },
      ),

    );
  }
}